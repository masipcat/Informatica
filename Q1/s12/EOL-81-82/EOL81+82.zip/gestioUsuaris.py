#!/usr/bin/python
# -*- coding: utf-8 -*-

def alumnesToStr(alumnes):
	txt = ""
	for k, v in alumnes.items():
		txt += "|0," + str(k) + "," + str(v)
	return txt

def projectesToStr(projectes):
	txt = ""
	for key, values in projectes.items():
		valors = ""
		for val in values:
			valors += "," + str(val)
		txt += "|1," + key + "," + valors[1:]
	return txt

def dictToStr(dic):
	return (alumnesToStr(dic["alumnes"]) + projectesToStr(dic["projectes"]))[1:]

def strToDict(txt):
	dic = {"alumnes": {}, "projectes": {}}
	for prop in txt.split("|"):
		prop = prop.split(",")
		#print "prop", prop
		if prop[0] == '0':
			dic["alumnes"][prop[1]] = prop[2]
		elif prop[0] == '1':
			dic["projectes"][prop[1]] = tuple(prop[2:])
	return dic

def addUser(dic, user, values):
	if not dic.has_key(user):
		dic[user] = {}
		modifyUser(dic, user, values)
		#print "\n[OK] S'ha creat l'usuari", user
		return True
	else:
		#print "\n[FAIL] L'usuari ja existeix"
		return False

def addProject(dic, key, values):
	"""
	Alias de 'addUser' per fer més coherent el nom
	"""
	return addUser(dic, key, values)

def delUser(dic, user):
	if dic.has_key(user):
		del dic[user]
		return True
	else:
		print "\n[FAIL] L'usuari no existeix"
		return False

def delProject(dic, key):
	"""
	Alias de 'delUser' per fer més coherent el nom
	"""
	return delUser(dic, key)

def modifyUser(dic, user, values):
	if dic.has_key(user):
		dic[user] = values
		return True
	else:
		addUser(dic, user)
		return modifyUser(dic, user, values)

def modifyProject(dic, key, values):
	"""
	Alias de 'modifyUser' per fer més coherent el nom
	"""
	return modifyUser(dic, key, values)

def desa(filename, dic):
	f = open(filename, "w")
	f.write(dictToStr(dic))
	#f.write(toStr(dic))
	f.close()
	print "\n[OK] S'han desat els canvis"

def obre(filename):
	f = open(filename, "r")
	content = f.read()
	f.close()
	dic = strToDict(content)
	if len(dic) == 0:
		print "\n[OK] S'ha carregat el fitxer, però és buit"
	else:
		print "\n[OK] S'ha carregat el fitxer"
	return dic